// Paquete equipo QA
const { defineConfig } = require('@playwright/test');
module.exports = defineConfig({
  testDir: '.',
  timeout: 0,
  workers: 1,            // una prueba a la vez, como en la suite original
  reporter: [['list']],
  use: { headless: false },
});
