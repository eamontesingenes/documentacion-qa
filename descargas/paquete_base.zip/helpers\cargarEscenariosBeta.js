// Paquete equipo QA - lector minimo de escenarios desde la matriz de Excel.
// Mismo contrato que el original: cargarEscenariosBeta(nombre) -> [escenarios].
// Eleccion de pruebas: $env:QA_CORREOS="7, 12, 20-25" (numeros, rangos o
// correos completos) o el archivo correos.txt junto al package.json.
const fs = require('fs');
const path = require('path');
// xlsx vendored (vendor/xlsx.full.min.js): no se instala por npm, viaja en el
// paquete. Por eso NUNCA falta aunque la testera no haya hecho npm install.
const XLSX = require('../vendor/xlsx.full.min.js');

const RAIZ = path.dirname(__dirname);
const CARPETA_MATRICES = path.join(RAIZ, 'matrices');

// Columnas del formulario 1 (hoja Calculo): encabezado -> campo del escenario.
const CAMPOS = [
  ['nombre', 'nombre'], ['apellido', 'apellido'], ['correo', 'correo'],
  ['lada', 'lada'], ['telefono', 'telefono'],
  ['edad_usuario', 'edad_usuario'], ['edad_pareja', 'edad_pareja'],
  ['objetivo', 'objetivo'], ['operada', 'operada'],
  ['sexo', 'sexo'], ['pareja', 'pareja'], ['tratamientos', 'tratamientos'],
  ['Tiempo buscando bebe', 'tiempo_buscando'], ['tiempo_bebe', 'tiempo_bebe'],
  ['embarazos', 'embarazos'], ['hijos', 'hijos'], ['gestacion', 'gestacion'],
  ['continuar_como', 'continuar_como'], ['pais', 'pais'], ['cp', 'cp'],
  ['accion_ubicacion', 'accion_ubicacion'], ['sucursal', 'sucursal'],
  ['pais_sucursal', 'pais_sucursal'], ['recomendacion', 'recomendacion'],
  ['como_nos_conociste', 'como_nos_conociste'], ['ocupacion', 'ocupacion'],
  ['ocupacion_pareja', 'ocupacion_pareja'], ['transporte', 'transporte'],
  ['estado_civil', 'estado_civil'], ['tarjeta', 'tarjeta'],
];

let HOJA_FILTRO = String(process.env.QA_HOJA || '').trim();

function entradasPedidas() {
  let crudo = String(process.env.QA_CORREOS || '').trim();
  if (!crudo) {
    const rutaTxt = path.join(RAIZ, 'correos.txt');
    if (fs.existsSync(rutaTxt)) {
      const lineas = fs.readFileSync(rutaTxt, 'utf-8')
        .split(/\r?\n/).map((l) => l.trim()).filter((l) => l && !l.startsWith('#'));
      // "hoja: Calculo" acota la busqueda cuando varias hojas comparten correos.
      const deHoja = lineas.find((l) => /^hoja\s*:/i.test(l));
      if (deHoja && !HOJA_FILTRO) HOJA_FILTRO = deHoja.split(':')[1].trim();
      crudo = lineas.filter((l) => !/^hoja\s*:/i.test(l)).join(',');
    }
  }
  const tokens = crudo.split(/[,;\s]+/).map((t) => t.trim()).filter(Boolean);
  const salida = [];
  for (const t of tokens) {
    const rango = t.match(/^(\d+)\s*-\s*(\d+)$/);
    if (rango && Number(rango[2]) >= Number(rango[1]) && Number(rango[2]) - Number(rango[1]) <= 100) {
      for (let n = Number(rango[1]); n <= Number(rango[2]); n++) salida.push(String(n));
    } else salida.push(t);
  }
  return salida;
}

function filasDeLasMatrices() {
  if (!fs.existsSync(CARPETA_MATRICES)) return [];
  const archivos = fs.readdirSync(CARPETA_MATRICES)
    .filter((a) => /\.(xlsm|xlsx)$/i.test(a) && !a.startsWith('~$') && !a.startsWith('_'));
  const filas = [];
  for (const archivo of archivos) {
    const libro = XLSX.readFile(path.join(CARPETA_MATRICES, archivo));
    for (const hoja of libro.SheetNames) {
      if (HOJA_FILTRO && hoja.toLowerCase() !== HOJA_FILTRO.toLowerCase()) continue;
      const datos = XLSX.utils.sheet_to_json(libro.Sheets[hoja], { header: 1, defval: '' });
      if (!datos.length) continue;
      const encabezados = datos[0].map((e) => String(e).trim());
      const iCorreo = encabezados.findIndex((e) => e.toLowerCase() === 'correo');
      if (iCorreo < 0) continue;
      const indices = CAMPOS.map(([origen]) => encabezados.indexOf(origen));
      for (let f = 1; f < datos.length; f++) {
        const correo = String(datos[f][iCorreo] || '').trim();
        if (!correo.includes('@')) continue;
        const esc = {};
        CAMPOS.forEach(([, salidaCampo], i) => {
          if (indices[i] >= 0) esc[salidaCampo] = datos[f][indices[i]];
        });
        esc.correo = correo;
        filas.push({ correo, archivo, hoja, escenario: esc });
      }
    }
  }
  return filas;
}

// "7" pesca _007 y _07: se compara el numero final del correo, como numero.
const numeroDe = (correo) => {
  const m = String(correo).match(/(\d+)(?:\.\d+)?@/);
  return m ? Number(m[1]) : null;
};

function cargarEscenariosBeta(nombreSpec) {
  const pedidas = entradasPedidas();
  if (!pedidas.length) {
    console.error('\n[Equipo QA] Dime que correr: $env:QA_CORREOS="7, 12, 20-25" o escribe los numeros en correos.txt.\n');
    return [];
  }
  const filas = filasDeLasMatrices();
  if (!filas.length) {
    console.error('\n[Equipo QA] No hay matriz: copia el .xlsm que te compartieron a la carpeta matrices/.\n');
    return [];
  }
  const escenarios = [];
  for (const pedida of pedidas) {
    let encontradas;
    if (pedida.includes('@')) {
      encontradas = filas.filter((x) => x.correo.toLowerCase() === pedida.toLowerCase());
    } else if (/^\d+$/.test(pedida)) {
      encontradas = filas.filter((x) => numeroDe(x.correo) === Number(pedida));
    } else {
      encontradas = [];
    }
    if (!encontradas.length) {
      console.error(`[Equipo QA] "${pedida}" no esta en la columna correo de ninguna matriz.`);
    } else if (encontradas.length > 1) {
      console.error(`[Equipo QA] "${pedida}" aparece en ${encontradas.length} sitios (${encontradas.map((x) => x.archivo + '/' + x.hoja).join(', ')}): usa el correo completo o acota con "hoja: <nombre>" en correos.txt (o $env:QA_HOJA).`);
    } else {
      console.log(`[Equipo QA] ${pedida} -> ${encontradas[0].correo}  (${encontradas[0].archivo} / ${encontradas[0].hoja})`);
      escenarios.push(encontradas[0].escenario);
    }
  }
  return escenarios;
}

module.exports = { cargarEscenariosBeta };
