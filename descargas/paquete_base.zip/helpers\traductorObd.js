// Dev. By Ing. Eder Montes 2026
// traductorObd.js — idioma del onboarding digital (QA_OBD_IDIOMA=en).
//
// El diccionario es EL DEL PRODUCTO: extraido de su bundle (chunk 3727 del
// deploy del 03/11/2026) y guardado tal cual en _obd_i18n.json con sus dos
// arboles es/en. Asi las etiquetas en ingles no se adivinan: son las mismas
// que pinta el formulario, ramas incluidas.
//
// El spec sigue razonando EN ESPAÑOL (claves, firmas, equivalencias, copys
// medidos: nada de eso se duplica): la traduccion vive en la frontera.
//   alIngles(fragmentoEs)      -> que etiqueta clickear en el DOM ingles
//   alInglesTodos(fragmento)   -> TODAS las variantes (Tengo/Tiene -> I have/Has)
//   alEspanol(textoEn)         -> encabezado/opcion leida, de vuelta a español
//     para que las regex de pantalla y los copys medidos sigan aplicando.
const fs = require('fs');
const path = require('path');

const modoIngles = () => String(process.env.QA_OBD_IDIOMA || '').trim().toLowerCase() === 'en';

// Normaliza para COMPARAR; nunca para devolver. Quita HTML porque el
// diccionario trae marcado ("Puedo <b>llevar el embarazo</b>") y el innerText
// del DOM no.
const norm = (t) => String(t ?? '').replace(/<[^>]+>/g, ' ')
  .normalize('NFD').replace(/[̀-ͯ]/g, '')
  .replace(/[¿?¡!.,;:·…]/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();

// Para DEVOLVER texto clickeable: sin tags, espacios colapsados, acentos y
// mayusculas intactos (clicarOpcion ya normaliza por su cuenta al comparar).
const visible = (t) => String(t ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

let PARES = null;        // [{es, en, esN, enN, esPregunta}]
let PLANTILLAS_EN = null; // hojas en con {x} -> regex (para alEspanol)
let PLANTILLAS_ES = null; // hojas es con {x} -> regex con captura (para alIngles)

function cargar() {
  if (PARES) return PARES;
  PARES = [];
  try {
    const d = JSON.parse(fs.readFileSync(path.join(__dirname, '_obd_i18n.json'), 'utf8'));
    (function caminar(es, en) {
      if (typeof es === 'string' && typeof en === 'string') {
        const esN = norm(es);
        if (esN) PARES.push({ es, en, esN, enN: norm(en), esPregunta: /[?？]\s*$/.test(visible(es)) });
        return;
      }
      if (es && en && typeof es === 'object' && typeof en === 'object') {
        for (const k of Object.keys(es)) if (en[k] !== undefined) caminar(es[k], en[k]);
      }
    })(d.es, d.en);
    // El es mas corto gana los empates de "contiene": un fragmento como
    // "Hombre" debe pescar la opcion, no una oracion larga que lo mencione.
    PARES.sort((a, b) => a.es.length - b.es.length);
  } catch (e) {
    console.warn(`traductorObd: no se pudo leer _obd_i18n.json (${e.message.split('\n')[0]}); los textos pasan tal cual.`);
  }
  return PARES;
}

const escaparRe = (t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Fragmento en español (los textos PARCIALES del spec) -> etiquetas COMPLETAS
// en ingles, TODAS las variantes del mejor nivel: exacto > plantilla ({brand}
// se captura y se sustituye) > empieza-con > contiene. Los TITULOS (hojas que
// terminan en "?") no son destino de click y se saltan — "inseminaciones"
// debe dar la opcion de tratamientos, no la pregunta de ciclos. Sin match se
// devuelve el fragmento tal cual: el click fallara VISIBLEMENTE (pantalla sin
// atender + titulosDesconocidos), nunca se adivina en silencio.
function alInglesTodos(fragmento) {
  if (!modoIngles()) return [fragmento];
  const f = norm(fragmento);
  if (!f) return [fragmento];
  const pares = cargar().filter((p) => !p.esPregunta);

  let nivel = pares.filter((p) => p.esN === f);
  if (!nivel.length) nivel = pares.filter((p) => p.esN.startsWith(f));
  if (!nivel.length) nivel = pares.filter((p) => p.esN.includes(f));
  if (!nivel.length) {
    // Plantillas AL FINAL: "No, encontré Ingenes por mi cuenta" pesca
    // "No, encontré {brand} por mi cuenta" y devuelve el en con Ingenes
    // puesto. Van al ultimo porque una plantilla generica ({a} de {b})
    // casaria fragmentos que SI tienen hoja literal ("ligadura of trompas").
    if (!PLANTILLAS_ES) {
      // Solo plantillas con parte literal sustanciosa: una casi pura comodin
      // ({a} de {b}) casaria cualquier cosa y fabricaria traducciones falsas.
      PLANTILLAS_ES = cargar().filter((p) => /\{\w+\}/.test(p.es) && norm(p.es.replace(/\{\w+\}/g, ' ')).length >= 10).map((p) => {
        const vars = [...p.es.matchAll(/\{(\w+)\}/g)].map((m) => m[1]);
        const re = new RegExp('^' + escaparRe(norm(p.es)).replace(/\\\{\w+\\\}/g, '(.+?)') + '$');
        return { p, re, vars };
      });
    }
    for (const t of PLANTILLAS_ES) {
      const m = t.re.exec(f);
      if (m) {
        let en = visible(t.p.en);
        t.vars.forEach((v, i) => { en = en.split(`{${v}}`).join(m[i + 1]); });
        return [en];
      }
    }
  }
  if (!nivel.length) return [fragmento];
  const vistos = new Set();
  const salida = [];
  for (const p of nivel) {
    const v = visible(p.en);
    if (!vistos.has(v)) { vistos.add(v); salida.push(v); }
  }
  return salida;
}

const alIngles = (fragmento) => alInglesTodos(fragmento)[0];

// Texto COMPLETO leido del DOM ingles -> su español del diccionario.
// Exacto > plantilla ({n}, {brand}... como comodin) > la hoja en mas larga
// contenida en el texto. Sin match devuelve el original.
function alEspanol(texto) {
  if (!modoIngles()) return texto;
  const t = norm(texto);
  if (!t) return texto;
  const pares = cargar();
  const exacto = pares.find((p) => p.enN === t);
  if (exacto) return visible(exacto.es);
  if (!PLANTILLAS_EN) {
    PLANTILLAS_EN = pares
      .filter((p) => /\{\w+\}/.test(p.en))
      .map((p) => ({ p, re: new RegExp('^' + escaparRe(p.enN).replace(/\\\{\w+\\\}/g, '.+') + '$') }));
  }
  const plantilla = PLANTILLAS_EN.find((x) => x.re.test(t));
  if (plantilla) return visible(plantilla.p.es);
  let mejor = null;
  for (const p of pares) {
    if (p.enN.length >= 6 && t.includes(p.enN) && (!mejor || p.enN.length > mejor.enN.length)) mejor = p;
  }
  return mejor ? visible(mejor.es) : texto;
}

module.exports = { modoIngles, alIngles, alInglesTodos, alEspanol };
